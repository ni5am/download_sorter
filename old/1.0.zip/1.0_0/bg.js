chrome.runtime.onInstalled.addListener(function(details){
    if(details.reason == "install"){
    	localStorage.defaultFolder = "default";
    	localStorage.rules = JSON.stringify([{"extension":"jpg","foldername":"images"},{"extension":"gif","foldername":"images"},{"extension":"jpeg","foldername":"images"}]);
    	chrome.tabs.create({url: "options.html"});
    }else if(details.reason == "update"){
        //var thisVersion = chrome.runtime.getManifest().version;
    }
});

function matches(extension, filename) {
	if(extension == ""){
		return false;
	}
	
	index = -1;
	index = filename.lastIndexOf('.');
	
	if(index != -1){
		type = filename.substring(index+1, filename.len);
	}
	
	if(type.toLowerCase() == extension.toLowerCase()){
		return true;
	}
	
	return false;
}

chrome.downloads.onDeterminingFilename.addListener(function(item, __suggest) {
		
	function suggest(filename, foldername) {
		__suggest({
			filename : foldername + "/" + filename
		});
	}

	var rules = localStorage.rules;

	try {
		rules = JSON.parse(rules);
	} catch (e) {
		localStorage.rules = JSON.stringify([]);
	}

	var found = false;
	for ( var index = 0; index < rules.length; ++index) {
		var rule = rules[index];
		if (matches(rule.extension, item.filename)) {
			suggest(item.filename, rule.foldername);
			found = true;
			break;
		}
	}

	if(!found){
		suggest(item.filename, localStorage.defaultFolder);
	}

});
